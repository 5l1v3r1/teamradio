TeamRadio = {}

--Addon Config
TeamRadio.Config = {}
TeamRadio.Config.GlobalRadio = {} -- Jobs who can talk to everybody
TeamRadio.radioChannel = {} -- DO NOT DELETE THIS LINE!

--Box
TeamRadio.Config.TextColor = Color(255, 255, 255)
TeamRadio.Config.TextBoxColor = Color(0, 0, 0, 180)

--Player
TeamRadio.Config.PlayerBoxColor = Color(52, 152, 219)
TeamRadio.Config.PlayerNameColor = Color(255, 255, 255)
TeamRadio.Config.KeyToTurnOn = IN_RELOAD
TeamRadio.Config.SwitchChannelKey = IN_ATTACK


--Channels will came here



TeamRadio.radioChannel[1] = {
	channelName = "Gouvernement",
	channelColor = Color( 0, 0, 255 ),
	jobs = { "gendarme" }
}