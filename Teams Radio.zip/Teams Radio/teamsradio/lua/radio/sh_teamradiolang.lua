TeamRadio_lang = {}

TeamRadio_lang.hasradio = "Votre métier a une radio pour plus d'info tapez !rradio"
TeamRadio_lang.inchannel = "Vous êtes dans la "
TeamRadio_lang.chatmsg = "[Radio] Pour allumer la radio appuyez sur Shift+R"
TeamRadio_lang.on = "Vous avez allumé la radio"
TeamRadio_lang.off = "Vous avez éteind votre radio"